These files are need to compile METIS on Windows.

Timothy A. Davis, http://www.suitesparse.com
